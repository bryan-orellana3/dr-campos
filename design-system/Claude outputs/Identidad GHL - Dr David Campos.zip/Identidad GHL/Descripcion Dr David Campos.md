# Descripción del instructor — Dr. David Campos

## Versión principal (para el perfil de instructor en GHL)

El Dr. David Campos es médico general boliviano radicado en São Paulo, Brasil, y uno de los médicos con mayor audiencia en habla hispana: cerca de 3,9 millones de seguidores combinados en TikTok, Facebook, Instagram y YouTube. Empezó grabando con su celular y una sola luz, sin agencia ni equipo de producción, y tardó dos años en cobrar sus primeros 100 dólares. Hoy sus redes le generan un ingreso mensual estable, le abrieron puertas a hospitales, clínicas, marcas y programas de televisión, y le traen pacientes de varios países sin buscarlos. Sigue ejerciendo la medicina: graba 30 videos por semana en sus fines de semana y publica todos los días. Su sello es hablar como le habla a un paciente en consulta, con rigor científico y sin perder cercanía. En el Método 4C (Constancia, Cercanía, Contenido y Conversión) documenta paso a paso la rutina real que siguió, para que otros médicos la repitan sin burnout y sin dejar la consulta.

## Versión corta (para tarjetas o bio de una línea, ~250 caracteres)

Médico general boliviano en São Paulo con ~3,9M de seguidores. Empezó con su celular y una luz; hoy sus redes le dan ingresos estables y pacientes de varios países mientras sigue ejerciendo. Enseña su rutina real en el Método 4C.
